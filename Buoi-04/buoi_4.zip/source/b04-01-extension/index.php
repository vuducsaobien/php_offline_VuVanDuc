<?php
    $input  = "D:/GoogleDrive/Doing/__psd/luutruonghailan/youtube-luutruonghailan-tamsu.psd";

    // Phần xử lý của học viên
    
    $output = [
        'name', 'extension'
    ];