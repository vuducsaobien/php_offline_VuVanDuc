<?php
    $zend = array(
                    'php'=>127,
                    'zend'=>20,
                    'html'=>32,
                    'type'=>12,
                    'javascript'=>80
    );

    // In ra khóa học có thời lượng video nhiều nhất
