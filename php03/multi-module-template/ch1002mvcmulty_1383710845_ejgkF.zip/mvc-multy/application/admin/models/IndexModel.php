<?php
class IndexModel extends Model{
	public function __construct(){
		echo '<h3>' . __METHOD__ . '</h3>';
	}
	
	public function listItems(){
		echo '<h3>' . __METHOD__ . '</h3>';
	}
}