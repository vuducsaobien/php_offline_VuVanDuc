<?php
	setcookie('name', 'This is a test', time() + 10);