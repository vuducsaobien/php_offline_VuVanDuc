<?php
	echo '<pre>';
	print_r($_COOKIE);
	echo '</pre>';
	
	echo $_COOKIE['name'];