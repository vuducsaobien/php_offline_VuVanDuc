<?php
	session_start();
	
	$_SESSION['name'] = 'Nguyen Van A';