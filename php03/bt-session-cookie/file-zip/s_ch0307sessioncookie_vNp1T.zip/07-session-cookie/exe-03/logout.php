<?php
	setcookie('fullName');
	header('location: login.php');
?>